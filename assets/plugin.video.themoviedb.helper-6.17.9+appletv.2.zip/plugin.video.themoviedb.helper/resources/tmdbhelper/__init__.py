from dexhub_tvos_compat import install
install()
