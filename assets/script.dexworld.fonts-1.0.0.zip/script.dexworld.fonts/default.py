import xbmcgui
from font_installer import install

result = install()
if result['failed']:
    message = 'تعذر تجهيز بعض الخطوط / Font installation incomplete:\n' + '\n'.join(result['failed'])
else:
    message = ('الخطوط جاهزة / Fonts ready: %d\n'
               'أعد تشغيل Kodi بالكامل، ثم إعدادات ← المشغل ← الترجمة ← الخط.\n'
               'Restart Kodi, then Settings → Player → Subtitles → Font.\n\n'
               'DexHub InterArabicRegular\nDexHub InterArabicBold\nDexHub InterArabicLight') % result['ready']
xbmcgui.Dialog().ok('DexWorld Subtitle Fonts', message)
