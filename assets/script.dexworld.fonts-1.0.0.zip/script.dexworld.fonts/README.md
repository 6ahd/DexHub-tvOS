# DexWorld Arabic Subtitle Fonts 1.0.0

Independent Kodi addon: the three font files are inside the ZIP. No network
download, skin dependency, player change, IPA rebuild or signing is needed.

1. Install this addon from ZIP and allow its service to run.
2. Open **DexWorld Arabic Subtitle Fonts** under Programs once to verify installation.
3. Completely close and reopen Kodi. The user-font family list is cached at startup.
4. Settings → Player → Subtitles → Font. Use Expert settings level if needed.
5. Choose `DexHub InterArabicRegular`, `DexHub InterArabicBold`, or `DexHub InterArabicLight`.

Destination: `special://home/media/Fonts/`. Copies are verified with SHA-256,
and an existing different file is not overwritten. Uninstalling the addon
does not remove copied fonts or change your chosen font. No Kodi font-cache
files or existing settings are edited.

The font affects Kodi text subtitles and the embedded Aether text bridge,
not bitmap subtitles or subtitles drawn by Infuse/VidHub. For ASS subtitles,
Kodi's override-font setting may be needed to use the selected font.

## عربي

ثبّت الإضافة من ZIP، ثم افتحها من إضافات البرامج للتأكد من تجهيز الخطوط.
أغلق Kodi وافتحه من جديد، ثم الإعدادات ← المشغل ← الترجمة ← الخط.
اختر أحد الأسماء الثلاثة أعلاه. الخطوط مدمجة في الحزمة؛ لا يلزم تنزيلها
من الإنترنت أو تغيير السكين أو إعادة بناء التطبيق.

## Fonts and licenses

The original font bytes are copied from the existing DexHub skin. Arabic and
English glyph coverage and distinct font family names are checked while packaging.
The fonts are modified Inter / IBM Plex Sans Arabic variants, including
supplementary Noto and DejaVu glyphs. Notices and licenses are in
`resources/licenses/`. Font files retain their own licenses; MIT applies only
to this installer code. Existing font family names are not changed.

This package has local installer/ZIP/font validation, not Apple TV runtime validation.
