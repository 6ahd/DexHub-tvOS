"""Install only the bundled fonts, verify bytes and preserve existing files."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

import xbmc
import xbmcaddon
import xbmcvfs

FONT_HOME = 'special://home/media/Fonts/'


def digest(path):
    with path.open('rb') as handle:
        return hashlib.sha256(handle.read()).hexdigest()


def install():
    result = dict(copied=0, ready=0, failed=[])
    try:
        addon = xbmcaddon.Addon('script.dexworld.fonts')
        source_root = xbmcvfs.translatePath(addon.getAddonInfo('path'))
        home = xbmcvfs.translatePath(FONT_HOME)
        if '://' in source_root or '://' in home or not source_root or not home:
            raise OSError('Kodi could not resolve the addon or user font directory')
        source = Path(source_root)/'resources/fonts'
        destination = Path(home)
        manifest = json.loads((source.parent/'fonts.json').read_text(encoding='utf-8'))
        destination.mkdir(parents=True, exist_ok=True)
        for font in manifest:
            temporary = None
            try:
                name = font['file']
                if Path(name).name != name or not name.endswith('.ttf'):
                    raise ValueError('Invalid bundled font filename')
                original = source/name
                if digest(original) != font['sha256']:
                    raise OSError('Bundled font failed verification: ' + name)
                target = destination/name
                if target.exists():
                    if digest(target) != font['sha256']:
                        raise OSError('Different existing file preserved: ' + name)
                    result['ready'] += 1
                    continue
                fd, temporary = tempfile.mkstemp(prefix='.dexworld-font-', dir=destination)
                os.close(fd)
                shutil.copyfile(original, temporary)
                temporary = Path(temporary)
                if digest(temporary) != font['sha256']:
                    raise OSError('Copied font failed verification: ' + name)
                if target.exists():
                    if digest(target) != font['sha256']:
                        raise OSError('Different existing file preserved: ' + name)
                else:
                    os.replace(temporary, target)
                    temporary = None
                    result['copied'] += 1
                result['ready'] += 1
            except (OSError, ValueError, KeyError) as error:
                result['failed'].append(str(error))
            finally:
                if temporary is not None:
                    Path(temporary).unlink(missing_ok=True)
        xbmc.log('[DexWorld Fonts] ready=%d copied=%d failed=%d directory=%s' %
                 (result['ready'], result['copied'], len(result['failed']), home), xbmc.LOGINFO)
    except (OSError, ValueError, KeyError) as error:
        result['failed'].append(str(error))
    for error in result['failed']:
        xbmc.log('[DexWorld Fonts] ' + error, xbmc.LOGERROR)
    return result
