import xbmc
import xbmcgui
from font_installer import install

if not xbmc.Monitor().waitForAbort(3):
    result = install()
    if result['failed']:
        xbmcgui.Dialog().notification('DexWorld Subtitle Fonts', 'تعذر تجهيز الخطوط. افتح الإضافة للتفاصيل / Open addon for details', xbmcgui.NOTIFICATION_ERROR)
    elif result['copied']:
        xbmcgui.Dialog().notification('DexWorld Subtitle Fonts', 'الخطوط جاهزة؛ أعد تشغيل Kodi / Fonts ready; restart Kodi', xbmcgui.NOTIFICATION_INFO)
